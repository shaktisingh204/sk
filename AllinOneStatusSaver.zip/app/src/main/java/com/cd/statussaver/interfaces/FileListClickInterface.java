package com.cd.statussaver.interfaces;

import java.io.File;

public interface FileListClickInterface {
    void getPosition(int position, File file);
}
