package com.cd.statussaver.util;

import android.content.ClipboardManager;

public abstract class ClipboardListener implements ClipboardManager.OnPrimaryClipChangedListener {

}
